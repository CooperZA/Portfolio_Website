<main id="about">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-header text-center main_1">
                    <h2>Who I Am</h2>
                </div>
            </div>
        </div>
        <section class="box main_1">
            <h4>A problem solver who strives to find simple and effective solutions.</h4>
        </section><!-- End of main_1 section -->
        <section class=" box main_1">
            <h4>A web development and data analytics specialist.</h4>
        </section><!-- End of main_1 section -->
        <section class="box main_1">
            <h4>An analytical thinker who is adaptable to any change.</h4>
        </section><!-- End of main_1 section -->
        <section class="box main_1">
            <h4>Someone who is always seeking the next challenge.</h4>
        </section><!-- End of main_1 section -->
    </div>
</main>