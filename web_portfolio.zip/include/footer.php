<footer>
    <p>
        Copyright &copy; <script>document.write(new Date().getFullYear())</script> Zach Cooper
    </p>
</footer>
<!-- <i class="far fa-copyright"></i> -->