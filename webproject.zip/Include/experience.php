<!-- Experience Section -->
<div id="exp"></div>
<section class="bg-color pt-10 pb-10">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="section-header text-center main_1">
                    <h2>Experience</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="box main_1">
                <i class="fas fa-book"></i>
                <h4>Knowledge is power</h4>
                <p>
                    With indepth experience in feilds like <strong>Finance</strong>, <strong>Information Technology</strong>, <strong>Web and Application Development</strong> and <strong>Data Analysis/Visualization</strong>. I have a diverse skill set that allows me to work dynamically in teams and produce high performance results.
                </p>
            </div>
            <div class="box main_1">
                <i class="fas fa-graduation-cap"></i>
                <h4>MIS and Ecommerce Development</h4>
                <p>
                    Whith a degree in Management Information Systems and a sepecialization in Ecommerce Development I can provide imense value to any project and team I work with.
                </p>
            </div>
            <div class="box main_1">
                <i class="fas fa-code"></i>
                <h4>Lanuages</h4>
                <p>
                    CSS3, C, HTML5, ES6, MySQL, Python, PHP
                </p>
            </div>
        </div>
    </div>
    <!-- end container -->
</section>