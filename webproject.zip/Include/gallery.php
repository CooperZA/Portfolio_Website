 <!-- begin main section -->
 <section id="gallery" class="main-padding bg-color">
     <!-- begin container -->
     <div class="container">
         <!-- begin container-gallery div -->
         <div class="container-gallery gallery">
             <div class="item">
                 <a href="images\4k-wallpaper-adventure-climb-691668.jpg" data-caption="Image caption">
                     <img src="images\4k-wallpaper-adventure-climb-691668.jpg" alt="Image 1" />
                 </a>
             </div>
             <div class="item">
                 <a href="images\adventure-calm-clouds-414171.jpg" data-caption="Image caption">
                     <img src="images\adventure-calm-clouds-414171.jpg" alt="Image 2" />
                 </a>
             </div>
             <div class="item">
                 <a href="images\adventure-clouds-high-163550.jpg" data-caption="Image caption">
                     <img src="images\adventure-clouds-high-163550.jpg" alt="Image 3" />
                 </a>
             </div>
             <div class="item">
                 <a href="images\adventure-cold-daylight-291732.jpg" data-caption="Image caption">
                     <img src="images\adventure-cold-daylight-291732.jpg" alt="Image 4" />
                 </a>
             </div>
         </div>
         <!-- end container-gallery div -->
     </div>
     <!-- end container -->
 </section>
 <!-- end main section -->