<div id="home">
    <div id="showcase">
        <div class="showcase-text">
            <div class="showcase-text-items">
                <h2 class="text-center">Welcome To My Website</h2>
                <p>
                    I believe in the power of technology and its ability to change peoples lives.
                </p>
                <a href="https://onedrive.live.com/embed?cid=20D43CC72FF9A07D&resid=20D43CC72FF9A07D%21139&authkey=APUtoqKquH4W938&em=2" download="ZachCooper_Resume.docx" class="btn btn-info"><i class="fas fa-download"></i> Resume</a>
                <a href="https://onedrive.live.com/embed?cid=20D43CC72FF9A07D&resid=20D43CC72FF9A07D%21388&authkey=AGly2rYwK79Jy9E&em=2" download="ZachCooper_CV.docx" class="btn btn-info"><i class="fas fa-download"></i> CV</a>
            </div><!-- End of showcase-text-items -->
        </div><!-- End of showcase-text -->
    </div><!-- End of showcase -->
</div><!-- /#home -->